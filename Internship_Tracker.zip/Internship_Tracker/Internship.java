import java.time.LocalDate;

/**
 * Stores information about one internship application.
 */
public class Internship {
    private String company;
    private String position;
    private String city;
    private String state;
    private String status;
    private LocalDate applicationDate;
    private String link;
    private String notes;

    /*
     * Constructs an internship with respective element 
     */
    public Internship(String company, String position, String city, String state,
                      String status, LocalDate applicationDate, String link, String notes) {
        this.company = company;
        this.position = position;
        this.city = city;
        this.state = state;
        this.status = status;
        this.applicationDate = applicationDate;
        this.link = link;
        this.notes = notes;
    }

    // Getter Methods 
    public String getCompany() {
        return company;
    }

    public String getPosition() {
        return position;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getStatus() {
        return status;
    }

    public LocalDate getApplicationDate() {
        return applicationDate;
    }

    public String getLink() {
        return link;
    }

    public String getNotes() {
        return notes;
    }

    // Setter Methods 
    public void setCompany(String company) {
        this.company = company;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setApplicationDate(LocalDate applicationDate) {
        this.applicationDate = applicationDate;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    /**
     * Returns one readable row for the internship tracker file.
     */
    public String toFileString() {
        return String.format("%-35.35s | %-55.55s | %-25.25s | %-15.15s | %-18.18s | %-12.12s | %-70.20s | %-80.80s",
                clean(company), clean(position), clean(city), clean(state), clean(status),
                applicationDate.toString(), clean(link), clean(notes));
    }
    /**
     * "Cleans" text to be able to go into one line of the file
     * @param text
     * 
     */
    private String clean(String text) {
        return text.replace("|", "/") /* Handles if the user types in "|" with anything*/
        .replace("\n", " ") 
        .replace("\r", " ");
    }

    public String toString() {
        String result = company + " - " + position + "\n" +
                        city + ", " + state + "\n" +
                        "Status: " + status + "\n" +
                        "Applied: " + applicationDate;

        // If the user wants to Links and Notes
        if (link.length() > 0) {
            result += "\nLink: " + link;
        }
        if (notes.length() > 0) {
            result += "\nNotes: " + notes;
        }
        return result;
    }
}
