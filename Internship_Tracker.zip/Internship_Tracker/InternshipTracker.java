import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Stores and manages all internship applications in the tracker.
 *
 * This class handles adding, searching, editing, removing, displaying,
 * loading, saving, statistics, and input validation.
 */
public class InternshipTracker {
    private static final String FILE_HEADING =
            String.format("%-35s | %-55s | %-25s | %-15s | %-18s | %-12s | %-70s | %-80s",
                    "COMPANY", "POSITION", "CITY", "STATE", "STATUS", "DATE APPLIED", "LINK", "NOTES");
    private static final String FILE_UNDERLINE =
            "------------------------------------|---------------------------------------------------------|---------------------------|-----------------|--------------------|--------------|-------------------------------------------------------------------|----------------------------------------------------------------------------------";

    private static final String FILE_EMPTY_ROW =
            String.format("%-35s | %-55s | %-25s | %-15s | %-18s | %-12s | %-70s | %-80s",
                    "", "", "", "", "", "", "", "");


    private ArrayList<Internship> internships;
    private String currentFileName;

    /**
     * Constructs an empty internship tracker with no file selected.
     */
    public InternshipTracker() {
        internships = new ArrayList<Internship>();
        currentFileName = "";
    }

    /**
     * Adds one or more internship applications entered by the user.
     *
     * @param input source of user input
     * @param output destination for prompts and messages
     */
    public void addInternship(Scanner input, PrintStream output) {
        char addMore = 'Y';

        output.println("\n========= Add Internship =========");

        while (addMore == 'Y') {
            Internship internship = readInternshipFromUser(input, output);
            internships.add(internship);
            output.println("\nInternship added.");
            addMore = readYesNo(input, output, "Add another internship? (Y/N): ");
        }
    }

    /**
     * Displays every internship currently stored in the tracker.
     *
     * @param output destination for internship information
     */
    public void displayAll(PrintStream output) {
        output.println("\n========= All Internships =========\n");

        if (internships.size() == 0) {
            output.println("No internships are stored.");
            return;
        }

        for (int i = 0; i < internships.size(); i++) {
            output.println((i + 1) + ". " + internships.get(i));
            output.println();
        }
        output.println("Total: " + internships.size() + " internship(s)");
    }

    /**
     * Searches stored internships by company, state, status, or position.
     *
     * @param input source of user input
     * @param output destination for prompts and search results
     */
    public void searchInternships(Scanner input, PrintStream output) {
        output.println("\n========= Search Internships =========");
        output.println("1. Search by Company");
        output.println("2. Search by State");
        output.println("3. Search by Status");
        output.println("4. Search by Position");

        int choice = readIntInRange(input, output, "Enter your choice: ", 1, 4);
        String search = readString(input, output, "Enter search value: ");
        int matches = 0;

        for (int i = 0; i < internships.size(); i++) {
            Internship internship = internships.get(i);
            boolean match = false;

            if (choice == 1) {
                match = internship.getCompany().toLowerCase().contains(search.toLowerCase());
            } else if (choice == 2) {
                match = internship.getState().equalsIgnoreCase(search);
            } else if (choice == 3) {
                match = internship.getStatus().equalsIgnoreCase(search);
            } else {
                match = internship.getPosition().toLowerCase().contains(search.toLowerCase());
            }

            if (match) {
                output.println("\n" + (i + 1) + ". " + internship);
                matches++;
            }
        }

        output.println("\nFound " + matches + " matching internship(s).");
    }

    /**
     * Displays application totals, status counts, and date-based statistics.
     *
     * The user can count applications from the last number of days or between
     * any two selected dates.
     *
     * @param input source of user input
     * @param output destination for prompts and statistics
     */
    public void displayStats(Scanner input, PrintStream output) {
        output.println("\n========= Internship Statistics =========");
        output.println("Total applications: " + internships.size());
        output.println("Applied: " + countStatus("Applied"));
        output.println("Under Review: " + countStatus("Under Review"));
        output.println("Interview: " + countStatus("Interview"));
        output.println("Rejected: " + countStatus("Rejected"));
        output.println("Offer: " + countStatus("Offer"));
        output.println("Withdrawn: " + countStatus("Withdrawn"));

        output.println("\nDate Statistics");
        output.println("1. Applications in the last number of days");
        output.println("2. Applications between two dates");
        output.println("3. Return to main menu");

        int choice = readIntInRange(input, output, "Enter your choice: ", 1, 3);

        if (choice == 1) {
            // LocalDate.now() keeps the calculation based on the current date.
            int days = readInt(input, output, "How many days back? ", 0);
            LocalDate today = LocalDate.now();
            LocalDate startDate = today.minusDays(days);
            int count = countApplicationsBetween(startDate, today);

            output.println("Applications from " + startDate + " through " + today + ": " + count);
        } else if (choice == 2) {
            LocalDate firstDate = readDate(input, output, "Enter first date (YYYY-MM-DD): ");
            LocalDate secondDate = readDate(input, output, "Enter second date (YYYY-MM-DD): ");

            // Swap the dates so the range works even if they are entered backwards.
            if (firstDate.isAfter(secondDate)) {
                LocalDate temp = firstDate;
                firstDate = secondDate;
                secondDate = temp;
            }

            int count = countApplicationsBetween(firstDate, secondDate);
            long difference = ChronoUnit.DAYS.between(firstDate, secondDate);

            output.println("Date difference: " + difference + " day(s)");
            output.println("Applications from " + firstDate + " through " + secondDate + ": " + count);
        }
    }

    /**
     * Allows the user to edit any field of an existing internship.
     *
     * The user may change one field at a time or replace all details at once.
     *
     * @param input source of user input
     * @param output destination for prompts and update messages
     */
    public void editInternship(Scanner input, PrintStream output) {
        if (internships.size() == 0) {
            output.println("\nNo internships are stored.");
            return;
        }

        displayShortList(output);
        int number = readIntInRange(input, output, "Select internship number to edit: ", 1, internships.size());
        Internship internship = internships.get(number - 1);
        char editMore = 'Y';

        while (editMore == 'Y') {
            output.println("\nCurrent internship:\n" + internship + "\n");
            output.println("1. Company");
            output.println("2. Position");
            output.println("3. City");
            output.println("4. State");
            output.println("5. Status");
            output.println("6. Application Date");
            output.println("7. Link");
            output.println("8. Notes");
            output.println("9. Replace ALL details");

            int choice = readIntInRange(input, output, "Enter your choice: ", 1, 9);

            // Update element of intership requested
            if (choice == 1) {
                internship.setCompany(readString(input, output, "New company: "));
            } else if (choice == 2) {
                internship.setPosition(readString(input, output, "New position: "));
            } else if (choice == 3) {
                internship.setCity(readString(input, output, "New city: "));
            } else if (choice == 4) {
                internship.setState(readString(input, output, "New state: "));
            } else if (choice == 5) {
                internship.setStatus(readStatus(input, output));
            } else if (choice == 6) {
                internship.setApplicationDate(readDate(input, output, "New application date (YYYY-MM-DD): "));
            } else if (choice == 7) {
                internship.setLink(readOptionalString(input, output, "New link (may be blank): "));
            } else if (choice == 8) {
                internship.setNotes(readOptionalString(input, output, "New notes (may be blank): "));
            } else {
                Internship replacement = readInternshipFromUser(input, output);
                internships.set(number - 1, replacement);
                internship = replacement;
            }

            output.println("Internship updated.");
            editMore = readYesNo(input, output, "Edit another field on this internship? (Y/N): ");
        }
    }

    /**
     * Removes a selected internship after the user confirms the deletion.
     *
     * @param input source of user input
     * @param output destination for prompts and messages
     */
    public void removeInternship(Scanner input, PrintStream output) {
        if (internships.size() == 0) {
            output.println("\nNo internships are stored.");
            return;
        }

        displayShortList(output);
        int number = readIntInRange(input, output, "\nSelect internship number to remove: ", 1, internships.size());
        Internship internship = internships.get(number - 1); 

        output.println("\n" + internship);
        char confirm = readYesNo(input, output, "Remove this internship? (Y/N): ");

        if (confirm == 'Y') {
            internships.remove(number - 1);
            output.println("Internship removed.");
        } else {
            output.println("Removal cancelled.");
        }
    }

    /**
     * Loads internship records from an existing tracker file.
     *
     * Existing internships in memory are cleared before the selected file is
     * loaded. Heading, underline, and divider-only rows are ignored.
     *
     * @param input source of user input
     * @param output destination for prompts and messages
     * @throws FileNotFoundException if the selected file cannot be opened
     */
    public void addFromFile(Scanner input, PrintStream output) throws FileNotFoundException {
        output.println("\n========= Load Internship File =========");
        output.print("Enter file name: ");
        String fileName = input.nextLine();
        File inputFile = new File(fileName);

        while (!inputFile.exists()) {
            output.print("File not found. Try again: ");
            fileName = input.nextLine();
            inputFile = new File(fileName);
        }

        Scanner fileInput = new Scanner(inputFile);
        int loaded = 0;

        while (fileInput.hasNextLine()) {
            // Read one physical row from the formatted text file.
            String line = fileInput.nextLine().trim();

            // Ignore the heading, underline, and blank lines.
            if (line.length() > 0 && !line.startsWith("COMPANY") && !line.startsWith("---") && !isEmptyDividerRow(line)) {
                Internship internship = parseInternship(line);
                if (internship != null) {
                    internships.add(internship);
                    loaded++;
                }
            }
        }

        fileInput.close();
        currentFileName = fileName;
        output.println("Loaded " + loaded + " internship(s).");
    }

    /**
     * Creates a new empty tracker file and writes the formatted heading.
     *
     * @param input source of user input
     * @param output destination for prompts and messages
     * @throws FileNotFoundException if the new file cannot be created
     */
    public void createNewFile(Scanner input, PrintStream output) throws FileNotFoundException {
        output.println("\n========= Create New Internship File =========");
        currentFileName = readString(input, output, "Enter new file name: ");
        internships.clear();

        PrintStream fileOutput = new PrintStream(new File(currentFileName));
        writeFileHeading(fileOutput);
        fileOutput.close();

        output.println("New tracker created with its heading: " + currentFileName);
    }

    /**
     * Saves all stored internships to the current tracker file.
     *
     * If no file has been selected yet, the user is asked for a file name.
     *
     * @param input source of user input
     * @param output destination for prompts and messages
     * @throws FileNotFoundException if the output file cannot be created
     */
    public void saveToFile(Scanner input, PrintStream output) throws FileNotFoundException {
        if (currentFileName.length() == 0) {
            output.print("Enter file name to save: ");
            currentFileName = input.nextLine();
        }

        PrintStream fileOutput = new PrintStream(new File(currentFileName));
        writeFileHeading(fileOutput);

        for (int i = 0; i < internships.size(); i++) {
            fileOutput.println(internships.get(i).toFileString());
            fileOutput.println(FILE_EMPTY_ROW);
        }

        fileOutput.close();
        output.println("Saved " + internships.size() + " internship(s) to " + currentFileName + ".");
    }

    /**
     * Writes the heading, underline, and empty divider row at the top of a file.
     *
     * @param fileOutput output stream connected to the tracker file
     */
    private void writeFileHeading(PrintStream fileOutput) {
        fileOutput.println(FILE_HEADING);
        fileOutput.println(FILE_UNDERLINE);
        fileOutput.println(FILE_EMPTY_ROW);
    }

    /**
     * Saves the tracker under a new file name and makes it the current file.
     *
     * @param input source of user input
     * @param output destination for prompts and messages
     * @throws FileNotFoundException if the new output file cannot be created
     */
    public void saveAs(Scanner input, PrintStream output) throws FileNotFoundException {
        output.print("Enter new file name: ");
        currentFileName = input.nextLine();
        saveToFile(input, output);
    }

    /**
     * Reads all information needed to create one internship.
     *
     * @param input source of user input
     * @param output destination for prompts
     * @return newly created internship containing the entered information
     */
    private Internship readInternshipFromUser(Scanner input, PrintStream output) {
        String company = readString(input, output, "\nCompany: ");
        String position = readString(input, output, "Position: ");
        String city = readString(input, output, "City: ");
        String state = readString(input, output, "State (example: MA or Texas): ");
        String status = readStatus(input, output);
        LocalDate applicationDate = readDate(input, output, "Application date (YYYY-MM-DD): ");
        String link = readOptionalString(input, output, "Job link (may be blank): ");
        String notes = readOptionalString(input, output, "Notes (may be blank): ");

        return new Internship(company, position, city, state, status, applicationDate, link, notes);
    }

    /**
     * Displays the status menu and returns the selected status text.
     *
     * @param input source of user input
     * @param output destination for prompts
     * @return selected internship status
     */
    private String readStatus(Scanner input, PrintStream output) {
        output.println("Status:");
        output.println("1. Applied");
        output.println("2. Under Review");
        output.println("3. Interview");
        output.println("4. Rejected");
        output.println("5. Offer");
        output.println("6. Withdrawn");

        int choice = readIntInRange(input, output, "Choose status: ", 1, 6);

        if (choice == 1) {
            return "Applied";
        } else if (choice == 2) {
            return "Under Review";
        } else if (choice == 3) {
            return "Interview";
        } else if (choice == 4) {
            return "Rejected";
        } else if (choice == 5) {
            return "Offer";
        } else {
            return "Withdrawn";
        }
    }

    /**
     * Counts internships that currently have the requested status.
     *
     * @param status status to count
     * @return number of internships with the requested status
     */
    private int countStatus(String status) {
        int count = 0;

        for (int i = 0; i < internships.size(); i++) {
            if (internships.get(i).getStatus().equalsIgnoreCase(status)) {
                count++;
            }
        }
        return count;
    }

    /**
     * Counts applications submitted between two dates, including both dates.
     *
     * @param firstDate beginning of the date range
     * @param secondDate end of the date range
     * @return number of applications inside the inclusive date range
     */
    private int countApplicationsBetween(LocalDate firstDate, LocalDate secondDate) {
        int count = 0;

        for (int i = 0; i < internships.size(); i++) {
            LocalDate date = internships.get(i).getApplicationDate();

            if (!date.isBefore(firstDate) && !date.isAfter(secondDate)) {
                count++;
            }
        }
        return count;
    }

    /**
     * Determines whether a file row contains only spaces and divider symbols.
     *
     * @param line line read from the tracker file
     * @return true if the row contains no internship information
     */
    private boolean isEmptyDividerRow(String line) {
        return line.replace("|", "").trim().length() == 0;
    }

    /**
     * Converts one tracker-file row into an Internship object.
     *
     * @param line file row containing eight "|" separated fields
     * @return parsed internship, or null if the row is invalid
     */
    private Internship parseInternship(String line) {
        // -1 keeps empty fields, which is important for optional link and notes.
        String[] fields = line.split("\\|", -1);

        if (fields.length != 8) {
            return null;
        }

        for (int i = 0; i < fields.length; i++) {
            fields[i] = fields[i].trim();
        }

        try {
            LocalDate date = LocalDate.parse(fields[5]);
            return new Internship(fields[0], fields[1], fields[2], fields[3],
                                  fields[4], date, fields[6], fields[7]);
        } catch (DateTimeParseException exception) {
            return null;
        }
    }

    /**
     * Displays a numbered summary list used when selecting an internship.
     *
     * @param output destination for the numbered internship list
     */
    private void displayShortList(PrintStream output) {
        output.println("\n========= Select Internship =========");
        for (int i = 0; i < internships.size(); i++) {
            Internship internship = internships.get(i);
            output.println((i + 1) + ". " + internship.getCompany() + " - " + internship.getPosition() +
                           " [" + internship.getStatus() + "]");
        }
    }

    /**
     * Reads a required nonempty line of text.
     *
     * @param input source of user input
     * @param output destination for prompts and validation messages
     * @param prompt prompt displayed before reading input
     * @return trimmed nonempty text entered by the user
     */
    public static String readString(Scanner input, PrintStream output, String prompt) {
        output.print(prompt);
        String value = input.nextLine().trim();

        while (value.length() == 0) {
            output.println("Input cannot be empty.");
            output.print(prompt);
            value = input.nextLine().trim();
        }
        return value;
    }

    /**
     * Reads a line of text that may be left empty.
     *
     * @param input source of user input
     * @param output destination for the prompt
     * @param prompt prompt displayed before reading input
     * @return trimmed text entered by the user, possibly an empty string
     */
    public static String readOptionalString(Scanner input, PrintStream output, String prompt) {
        output.print(prompt);
        return input.nextLine().trim();
    }

    /**
     * Reads an integer that is at least the specified minimum value.
     *
     * @param input source of user input
     * @param output destination for prompts and validation messages
     * @param prompt prompt displayed before reading input
     * @param minimum smallest accepted integer
     * @return validated integer greater than or equal to minimum
     */
    public static int readInt(Scanner input, PrintStream output, String prompt, int minimum) {
        while (true) {
            output.print(prompt);

            if (!input.hasNextInt()) {
                output.println("Invalid number.");
                input.nextLine();
            } else {
                int value = input.nextInt();
                input.nextLine();

                if (value < minimum) {
                    output.println("Please enter a value of at least " + minimum + ".");
                } else {
                    return value;
                }
            }
        }
    }

    /**
     * Reads an integer inside an inclusive minimum-to-maximum range.
     *
     * @param input source of user input
     * @param output destination for prompts and validation messages
     * @param prompt prompt displayed before reading input
     * @param minimum smallest accepted integer
     * @param maximum largest accepted integer
     * @return validated integer between minimum and maximum, inclusive
     */
    public static int readIntInRange(Scanner input, PrintStream output, String prompt,
                                     int minimum, int maximum) {
        int value = readInt(input, output, prompt, minimum);

        while (value > maximum) {
            output.println("Please enter a number from " + minimum + " to " + maximum + ".");
            value = readInt(input, output, prompt, minimum);
        }
        return value;
    }

    /**
     * Reads and validates a yes-or-no response.
     *
     * @param input source of user input
     * @param output destination for prompts and validation messages
     * @param prompt prompt displayed before reading input
     * @return uppercase 'Y' or 'N'
     */
    public static char readYesNo(Scanner input, PrintStream output, String prompt) {
        output.print(prompt);
        String answer = input.nextLine().trim().toUpperCase();

        while (answer.length() != 1 || (answer.charAt(0) != 'Y' && answer.charAt(0) != 'N')) {
            output.print("Please enter Y or N: ");
            answer = input.nextLine().trim().toUpperCase();
        }
        return answer.charAt(0);
    }

    /**
     * Reads a valid date in ISO YYYY-MM-DD format.
     *
     * @param input source of user input
     * @param output destination for prompts and validation messages
     * @param prompt prompt displayed before reading input
     * @return validated LocalDate entered by the user
     */
    public static LocalDate readDate(Scanner input, PrintStream output, String prompt) {
        while (true) {
            output.print(prompt);
            String text = input.nextLine().trim();

            // Handles invalid format and date
            try {
                return LocalDate.parse(text);
            } catch (DateTimeParseException exception) {
                output.println("Invalid date. Use YYYY-MM-DD, for example 2026-08-25.");
            }
        }
    }
}
