import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

/**
 * Runs the internship tracker program.
 */
public class InternshipTrackerManagement {
    private static final int FIRST_MENU_CHOICE = 1;
    private static final int EXIT_CHOICE = 10;

    public static void main(String[] args) throws FileNotFoundException {
        Scanner input = new Scanner(System.in);
        PrintStream output = System.out;
        InternshipTracker tracker = new InternshipTracker();

        printWelcome(output);
        startupMenu(tracker, input, output);

        int menuChoice = 0;

        while (menuChoice != EXIT_CHOICE) {
            printMenu(output);
            menuChoice = InternshipTracker.readIntInRange(
                    input, output, "Enter your choice: ", FIRST_MENU_CHOICE, EXIT_CHOICE);

            if (menuChoice == 1) {
                tracker.addInternship(input, output);
            } else if (menuChoice == 2) {
                tracker.displayAll(output);
            } else if (menuChoice == 3) {
                tracker.searchInternships(input, output);
            } else if (menuChoice == 4) {
                tracker.displayStats(input, output);
            } else if (menuChoice == 5) {
                tracker.editInternship(input, output);
            } else if (menuChoice == 6) {
                tracker.removeInternship(input, output);
            } else if (menuChoice == 7) {
                tracker.addFromFile(input, output);
            } else if (menuChoice == 8) {
                tracker.saveToFile(input, output);
            } else if (menuChoice == 9) {
                tracker.saveAs(input, output);
            } else {
                char save = InternshipTracker.readYesNo(input, output, "Save before exiting? (Y/N): ");
                if (save == 'Y') {
                    tracker.saveToFile(input, output);
                }
                output.println("Good bye!");
            }
        }

        input.close();
    }

    private static void startupMenu(InternshipTracker tracker, Scanner input, PrintStream output)
            throws FileNotFoundException {
        output.println("\n1. Load an existing internship file");
        output.println("2. Create a new internship file");
        output.println("3. Start without choosing a file yet");

        int choice = InternshipTracker.readIntInRange(input, output, "Enter your choice: ", 1, 3);

        if (choice == 1) {
            tracker.addFromFile(input, output);
        } else if (choice == 2) {
            tracker.createNewFile(input, output);
        }
    }

    public static void printWelcome(PrintStream output) {
        output.println("Welcome to the Internship Application Tracker!");
    }

    public static void printMenu(PrintStream output) {
        output.println("\n========= Internship Tracker =========\n");
        output.println("1. Add Internship");
        output.println("2. Display All Internships");
        output.println("3. Search Internships");
        output.println("4. View Statistics");
        output.println("5. Edit Internship");
        output.println("6. Remove Internship");
        output.println("7. Add Internsiop from File");
        output.println("8. Save");
        output.println("9. Save As");
        output.println("10. Exit\n");
    }
}
